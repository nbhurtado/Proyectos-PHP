<?php 
	
	/*		REDIRECCIONA AL INDEX DEL PUBLIC 		*/

	require'public/index.php';

	/*		FIN DE INDEX 		*/