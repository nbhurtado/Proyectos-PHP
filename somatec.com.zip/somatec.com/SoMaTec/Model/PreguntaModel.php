<?php namespace SoMaTec\Model;

	use SoMaTec\Model\RespuestaModel as RM;
	use SoMaTec\Model\CategoriaModel as CM;
	use SoMaTec\Model\Clase\Usuario as CUsuario;
	use SoMaTec\Model\UsuarioModel as UM;
	use SoMaTec\Model\Action\Pregunta as APregunta;
	use SoMaTec\Model\Clase\Pregunta as CPregunta;
	use SoMaTec\Helpers\Security as HS;

	class PreguntaModel 
	{

		/*		CONSTANTE NAMESPACE PREGUNTA 		*/
		
		const PREGUNTA_NAMESPACE = 'SoMaTec\Model\Clase\Pregunta';
		
		/*	**	*/

		/*		CONSTRUCTOR 		*/
		
		public function __construct()
		{

		}
		
		/*	**	*/

		/*		TODAS LAS SOLICITUDES QUE RECIVE EL ADMINISTRADOR 		*/
		
		public static function all()
		{
			$c_user = new CUsuario();
			if(isset($_SESSION['user']['id']) && isset($_SESSION['user']['email']))
			{
				$user = UM::id($_SESSION['user']['id']);

				if($user->getTipo() == "admin")
				{
					$a_pregunta = new APregunta();			
					$preguntas  = $a_pregunta->getAll(self::PREGUNTA_NAMESPACE);

					if(! isset($preguntas)) return null;

					foreach ($preguntas as $index => $pregunta_actual) {
						$pregunta_actual->setCategoria(CM::id($pregunta_actual->getIdCategoria()));
						$pregunta_actual->setUsuario(UM::id($pregunta_actual->getIdUsuario()));

						$respuestas = RM::replysForQuestionId($pregunta_actual->getId(), RM::RESPUESTA_NAMESPACE);

						if ( ! isset($respuestas) ) continue;

						$pregunta_actual->setOBJRespuestas($respuestas);				
						$preguntas[$index] = $pregunta_actual;

					}

					return $preguntas;
				}
			}
			else
			{
				return null;
			}
		}
		
		/*	**	*/

		/*		ALL QUESTION FOR DENIED 		*/
		
		public static function allDenied()
		{
			$a_pregunta = new APregunta();
			$preguntas = $a_pregunta->runSql("SELECT * FROM pregunta WHERE denuncias > 0 ORDER BY denuncias DESC", self::PREGUNTA_NAMESPACE);
			
			if (! is_object($preguntas) && ! is_array($preguntas)) return null;

			elseif(is_object($preguntas))
			{
				$preguntas = array ($preguntas);
			}

			foreach ($preguntas as $index => $pregunta_actual) {
				$pregunta_actual->setCategoria(CM::id($pregunta_actual->getIdCategoria()));
				$pregunta_actual->setUsuario(UM::id($pregunta_actual->getIdUsuario()));

				$respuestas = RM::replysForQuestionId($pregunta_actual->getId(), RM::RESPUESTA_NAMESPACE);

				if ( ! isset($respuestas) ) continue;

				$pregunta_actual->setOBJRespuestas($respuestas);				
				$preguntas[$index] = $pregunta_actual;

			}

			return $preguntas;
		}
				
		
		/*	**	*/

		/*		PREGUNTA POR ID 		*/
		
		public static function id($id)
		{
			$a_pregunta = new APregunta();
			
			$pregunta   = $a_pregunta->getById($id, self::PREGUNTA_NAMESPACE);

			if(! isset($pregunta)) return null;

			$pregunta->setCategoria(CM::id($pregunta->getIdCategoria()));
			$pregunta->setUsuario(UM::id($pregunta->getIdUsuario()));

			$respuesta = RM::replysForQuestionId($pregunta->getId(), RM::RESPUESTA_NAMESPACE);
			
			if (isset($respuesta))
			{
				$pregunta->setOBJRespuestas($respuesta);
			}
			else
			{
				$pregunta->setOBJRespuestas(null);
			}

			return $pregunta;
		}
		
		/*	**	*/

		/*		PREGUNTA POR TITULO 		*/
		
		public static function titulo($titulo)
		{
			$a_pregunta = new APregunta();
			
			$pregunta   = $a_pregunta->getBy('titulo', $titulo, self::PREGUNTA_NAMESPACE)[0];
			
			if(! isset($pregunta)) return null;

			$pregunta->setCategoria(CM::id($pregunta->getIdCategoria()));
			$pregunta->setUsuario(UM::id($pregunta->getIdUsuario()));

			$respuesta = RM::replysForQuestionId($pregunta->getId(), RM::RESPUESTA_NAMESPACE);
			
			if (isset($respuesta))
			{
				$pregunta->setOBJRespuestas($respuesta);
			}
			else
			{
				$pregunta->setOBJRespuestas(null);
			}

			return $pregunta;
		}
		
		/*	**	*/

		/*		PREGUNTA POR CATEGORIA 		*/
		
		public static function getQuestionCategory($id_categoria)
		{
			$id_categoria = HS::clean_input($id_categoria);

			$a_pregunta = new APregunta();
			$preguntas = $a_pregunta->getBy("fk_id_categoria", $id_categoria, self::PREGUNTA_NAMESPACE);
			if (! is_object($preguntas) && ! is_array($preguntas)) return null;

			elseif(is_object($preguntas))
			{
				$preguntas = array ($preguntas);
			}

			foreach ($preguntas as $index => $pregunta_actual) {
				$pregunta_actual->setCategoria(CM::id($pregunta_actual->getIdCategoria()));
				$pregunta_actual->setUsuario(UM::id($pregunta_actual->getIdUsuario()));

				$respuestas = RM::replysForQuestionId($pregunta_actual->getId(), RM::RESPUESTA_NAMESPACE);

				if ( ! isset($respuestas) ) continue;

				$pregunta_actual->setOBJRespuestas($respuestas);				
				$preguntas[$index] = $pregunta_actual;

			}

			return $preguntas;
		}
		
		/*	**	*/

		/*		PREGUNTA POR ID USUARIO 		*/
		
		public static function getQuestionIdUser($id_user)
		{
			$id_user = HS::clean_input($id_user);

			$a_pregunta = new APregunta();
			$preguntas = $a_pregunta->getBy("fk_id_usuario", $id_user, self::PREGUNTA_NAMESPACE);
			if (! is_object($preguntas) && ! is_array($preguntas)) return null;

			elseif(is_object($preguntas))
			{
				$preguntas = array ($preguntas);
			}

			foreach ($preguntas as $index => $pregunta_actual) {
				$pregunta_actual->setCategoria(CM::id($pregunta_actual->getIdCategoria()));
				$pregunta_actual->setUsuario(UM::id($pregunta_actual->getIdUsuario()));

				$respuestas = RM::replysForQuestionId($pregunta_actual->getId(), RM::RESPUESTA_NAMESPACE);

				if ( ! isset($respuestas) ) continue;

				$pregunta_actual->setOBJRespuestas($respuestas);				
				$preguntas[$index] = $pregunta_actual;

			}

			return $preguntas;
		}
		
		/*	**	*/

		/*		BUSCAR PREGUNTA		*/
		
		public static function searchQuestion($patron)
		{
			$patron = HS::clean_input($patron);

			$a_pregunta = new APregunta();
			$preguntas = $a_pregunta->runSql("SELECT * FROM pregunta WHERE titulo LIKE '%" . $patron . "%'", self::PREGUNTA_NAMESPACE);
			if (! is_object($preguntas) && ! is_array($preguntas)) return null;

			elseif(is_object($preguntas))
			{
				$preguntas = array ($preguntas);
			}

			foreach ($preguntas as $index => $pregunta_actual) {
				$pregunta_actual->setCategoria(CM::id($pregunta_actual->getIdCategoria()));
				$pregunta_actual->setUsuario(UM::id($pregunta_actual->getIdUsuario()));

				$respuestas = RM::replysForQuestionId($pregunta_actual->getId(), RM::RESPUESTA_NAMESPACE);

				if ( ! isset($respuestas) ) continue;

				$pregunta_actual->setOBJRespuestas($respuestas);				
				$preguntas[$index] = $pregunta_actual;

			}

			return $preguntas;
		}
		
		/*	**	*/

		/*		PREGUNTAS CON ID MAYOR A X 		*/
		
		public static function getQuestionRealTime($id)
		{
			$id = HS::clean_input($id);

			$a_pregunta = new APregunta();
			$preguntas = $a_pregunta->runSql("SELECT * FROM pregunta WHERE id_pregunta > " . $id . "", self::PREGUNTA_NAMESPACE);
			if (! is_object($preguntas) && ! is_array($preguntas)) return null;

			elseif(is_object($preguntas))
			{
				$preguntas = array ($preguntas);
			}

			foreach ($preguntas as $index => $pregunta_actual) {
				$pregunta_actual->setCategoria(CM::id($pregunta_actual->getIdCategoria()));
				$pregunta_actual->setUsuario(UM::id($pregunta_actual->getIdUsuario()));

				$respuestas = RM::replysForQuestionId($pregunta_actual->getId(), RM::RESPUESTA_NAMESPACE);

				if ( ! isset($respuestas) ) continue;

				$pregunta_actual->setOBJRespuestas($respuestas);				
				$preguntas[$index] = $pregunta_actual;

			}

			return $preguntas;
		}
		
		/*	**	*/

		/*		DENUNCIAR PREGUNTA 		*/
		
		public static function denunciarPregunta($id)
		{
			$pregunta = self::id($id);

			if(! isset($pregunta)) return false;

			return self::updateQuestion($pregunta->getId(), $pregunta->getTitulo(), $pregunta->getCuerpo(), $pregunta->getDenuncias() + 1, $pregunta->getIdCategoria());
		}
		
		/*	**	*/

		/*		SAVE 		*/
		
		public static function saveQuestion($titulo, $cuerpo, $fecha, $respuestas, $ultima_repuesta, $id_usuario, $denuncias, $id_categoria)
		{
			$a_pregunta = new APregunta();

			$c_pregunta = new CPregunta();
			$c_pregunta->setTitulo($titulo);
			$c_pregunta->setCuerpo($cuerpo);
			$c_pregunta->setFecha($fecha);
			$c_pregunta->setRespuestas($respuestas);
			$c_pregunta->setUltimaRespuesta($ultima_repuesta);
			$c_pregunta->setIdUsuario($id_usuario);
			$c_pregunta->setDenuncias($denuncias);
			$c_pregunta->setIdCategoria($id_categoria);

			return $a_pregunta->save($c_pregunta);
		}
		
		/*	**	*/

		/*		UPDATE 		*/
		
		public static function updateQuestion($id, $titulo, $cuerpo, $denuncias, $id_categoria)
		{
			$a_pregunta = new APregunta();

			$c_pregunta = new CPregunta();
			$c_pregunta->setId($id);
			$c_pregunta->setTitulo($titulo);
			$c_pregunta->setCuerpo($cuerpo);
			$c_pregunta->setDenuncias($denuncias);
			$c_pregunta->setIdCategoria($id_categoria);

			return $a_pregunta->update($c_pregunta);
		}
		
		/*	**	*/

		/*		DELETE 		*/
		
		public static function deleteQuestion($id)
		{
			$a_pregunta = new APregunta();

			$c_pregunta = new CPregunta();
			$c_pregunta->setId($id);

			return $a_pregunta->delete($c_pregunta);
		}
		
		/*	**	*/

	}

/*		FIN CLASS PREGUNTA MODEL		*/