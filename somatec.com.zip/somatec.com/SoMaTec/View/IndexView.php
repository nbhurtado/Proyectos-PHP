<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?=$helper->pladi_favicon();?>
	<title>SoMaTec</title>
	<?= $helper->css('ed-grid')?>
	<?= $helper->css('index')?>
	<?= $helper->css('menu-footer')?>

</head>
<body>
	
	<header id="header">
		<div class="container"> 
			<nav id="menu">
				<?= $helper->pladi_menu() ?>				
			</nav>
			<section id="banner">			
				<div class="grupo centrar-contenido">
					<div class="caja banner__descripcion">
						<span><?= $helper->frase() ?></span>
					</div>
					<div class="caja banner__boton">
						<button>Comienza Ahora</button>
					</div>
				</div>	
			</section>
		</div>
	</header>

	<main id="main">
		<section id="usuarios">
			<div class="grupo">
				<div class="caja">
					<h1 class="usuarios__titulo">Nuestra comunidad</h1>
				</div>
			</div>
			<?php if(isset($usuarios)): ?>
				<div class="grupo">			
					<?php foreach($usuarios as $usuario): ?>

						<div class="caja centrar-contenido base-50 movil-1-3 tablet-1-6 web-1-8">
							<img id="<?=$usuario->getId();?>" class="usuario__imagen" src="<?=$usuario->getPerfilUsuario()->getFoto(true) != NULL ? $usuario->getPerfilUsuario()->getFoto(true) : $helper->base_url().'img/users/template.png' ?>" alt="user <?=$usuario->getNombre()?>">
							<p class="usuario__nombre"><?=$usuario->getNombre();?></p>
						</div>

					<?php endforeach; ?>				
				</div>
			<?php else: ?>
				<div class="grupo">
					<div class="caja sin__preguntas">
						<h2 class="error">No hay usuarios</h2>
					</div>
				</div>
			<?php endif; ?>
		</section>
	</main>

	<footer id="footer">
		<?= $helper->pladi_footer()?>
	</footer>

	<!-- scripts-->
	<?= $helper->js('jquery')?>
	<?= $helper->js('variables-globales')?>
	<?= $helper->js('eventos')?>
</body>
</html>
	