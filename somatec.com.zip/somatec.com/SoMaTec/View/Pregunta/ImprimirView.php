	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?=$helper->pladi_favicon();?>
	<title>SoMaTec - Home</title>
	<?= $helper->css('ed-grid')?>
	<?= $helper->css('menu-footer')?>
	<?= $helper->css('formulario')?>
	<?= $helper->css('home')?>
	<?= $helper->css('admin')?>
</head>
<body>
	<header id="header">
		<div class="container"> 
			<nav id="menu">
				<?= $helper->pladi_home_menu_admin($usuario->getNombre()); ?>
			</nav>
		</div>
	</header>
	
	<main id="imprimir">
		<div class="grupo">
			<secction class="cabecera">
				<div class="caja movil-20">
					<?=$helper->img('escudo.png')?>
				</div>
				<div class="caja movil-60">
				   	<h3>GOBIERNO REGIONAL DE APURIMAC </h3>
					<h3>DIRECCIÓN REGIONAL DE SALUD APURÍMAC</h3>
					<h5>"Año de la Consolidación del Mar del Grau"</h5>
				</div>
				<div class="caja movil-20">
				    <?=$helper->img('diresa.jpg')?>
				</div>
			</secction>
			<section class="caja cuerpo padding-2 centro-contenido">
				<h1>INFORME TÉCNICO</h1>
			</section>
			<div class="caja ">
				<div class="caja movil-50">
					<table>
						<tr>
							<td>dia</td>
							<td>mes</td>
							<td>año</td>
						</tr>
						<tr>
							<td>18</td>
							<td>mayo</td>
							<td>2016</td>
						</tr>
					</table>
				</div>
				<div class="caja movil-50 derecha-contenido">
					<table class="derecha">
						<tr>
							<td>dia</td>
							<td>mes</td>
							<td>año</td>
						</tr>
						<tr>
							<td>28</td>
							<td>nobiembre</td>
							<td>2016</td>
						</tr>
					</table>
				</div>
			</div>
			
		</div>

	</main>

	<!-- scripts-->
	<?= $helper->js('jquery')?>
	<?= $helper->js('variables-globales')?>
	<?= $helper->js('eventos')?>
	<?= $helper->js('banear')?>
</body>
</html> 