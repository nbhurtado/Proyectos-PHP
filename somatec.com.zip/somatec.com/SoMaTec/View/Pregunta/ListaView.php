<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?=$helper->pladi_favicon();?>
	<title>SoMaTec - Home</title>
	<?= $helper->css('ed-grid')?>
	<?= $helper->css('menu-footer')?>
	<?= $helper->css('formulario')?>
	<?= $helper->css('home')?>
	<?= $helper->css('admin')?>
</head>
<body>
	<header id="header">
		<div class="container"> 
			<nav id="menu">
				<?= $helper->pladi_home_menu_admin($usuario->getNombre()); ?>
			</nav>
		</div>
	</header>
	
	<main id="principal">
		
		<?php if(isset($preguntas)): ?>
			<div id="preguntas">			
				<?php foreach($preguntas as $pregunta): ?>
					<article class="pregunta_item limpiar">
					<div class="grupo">
						<div class="caja pregunta__titulo base-10 tablet-80">
							<p><?=$pregunta->getTitulo()?></p>
						</div>
						<div class="caja pregunta__eliminar base-10 tablet-20 derecha-contenido">
							<a class="icon-cerrar espacio eliminar_pregunta" data-id="<?=$pregunta->getId()?>"></a>
						</div>
						<div class="caja pregunta__fecha base-90 tablet-80 izquierda-contenido">					
							<p><?=$helper->fecha_amigable($pregunta->getFecha())?></p>
						</div>
						<div class="caja pregunta__editar base-10 tablet-20 derecha-contenido">
							<a href="<?=$helper->url('pregunta','imprimir')?>" class="icon-aceptar espacio eliminar_editar" data-id="<?=$pregunta->getId()?>"></a>
						</div>
						<div class="caja pregunta__categoria tablet-50 izquierda-contenido">
							<p><?=$pregunta->getCategoria()->getNombre()?></p>
						</div>
						<div class="caja pregunta__email tablet-50 izquierda-contenido">
							<p><?=$pregunta->getUsuario()->getEmail()?></p>
						</div>
					</div>
					</article>
				<?php endforeach; ?>				
			</div>
		<?php else: ?>
			<div class="grupo">
				<div class="caja sin__preguntas">
					<h2 class="error">No hay Preguntas Denunciadas</h2>
				</div>
			</div>
		<?php endif; ?>


	</main>

	<!-- scripts-->
	<?= $helper->js('jquery')?>
	<?= $helper->js('variables-globales')?>
	<?= $helper->js('eventos')?>
	<?= $helper->js('banear')?>
</body>
</html> 