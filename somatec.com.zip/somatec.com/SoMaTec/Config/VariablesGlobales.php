<?php namespace SoMaTec\Config;

	class VariablesGlobales
	{
		/*		CONTROLADOR POR DEFECTO 		*/
		
		public static $controlador_defecto = "Index";
		
		/*	**	*/
		
		/*		ACCION POR DEFECTO 		*/
		
		public static $accion_defecto      = "index";
		
		/*	**	*/

		/*		SUB-RUTA [ CARPETA] 		*/

		public static $base_url = "http://diresaapurimac.gob.pe/somatec.com/public/"; // en caso de usar dominio [ejemplo.com] dejar en blanco
		
		/*  **  */

		/* 		SUB-RUTA [ RULE VIEW ]		 */

		public static $base_url_view = "http://diresaapurimac.gob.pe/somatec.com/public";
		
		/*  **  */
	}
/*		FIN CLASS VARIABLES GLOBALES		*/