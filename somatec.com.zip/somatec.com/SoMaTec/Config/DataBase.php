<?php namespace SoMaTec\Config;

	class DataBase
	{

		/*		DRIVER DE CONEXION 		*/
		
		public static $driver   = "mysql";
		
		/*	**	*/
		
		/*		HOST 		*/
		
		public static $host     = "localhost";
		
		/*	**	*/
		
		/*		USUARIO BD 		*/
		
		public static $user     = "diresaap_somatec";
		
		/*	**	*/
		
		/*		CONTRASEÑA BD 		*/
		
		public static $pass     = "somatec1232";
		
		/*	**	*/
		
		/*		NOMBRE DE LA BD 		*/
		
		public static $database = "diresaap_somatec";
		
		/*	**	*/
		
		/*		CHARSET 		*/
		
		public static $charset  = "utf8";
		
		/*	**	*/

	}
/*		FIN CLASS DB 		*/
