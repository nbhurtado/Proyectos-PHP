<?php namespace SoMaTec\Controller;

	use SoMaTec\Core\ControladorBase;

	use SoMaTec\Model\CategoriaModel as CM;
	use SoMaTec\Model\PreguntaModel as PM;
	use SoMaTec\Model\UsuarioModel as UM;

	class CategoriaController extends ControladorBase
	{
		
		/*		INDEX 		*/
		
		public function index()
		{
			$this->redirect();
		}

		
		/*	**	*/

		/*		FILTRADO DE PREGUNTAS POR CATEGORIA 		*/
		
		public function filter($id)
		{
			session_start();
			
			if(isset($_SESSION['user']['id']) && isset($_SESSION['user']['email']))
			{
				$preguntas = PM::getQuestionCategory($id);				
				$user      = UM::id($_SESSION['user']['id']);
				
				$data      = array(
					"usuario"   => $user,
					"preguntas" => $preguntas
				);

				if(! isset($preguntas) || empty($preguntas)) $this->view('Errors/404');
				else $this->view('Home', $data);
			}
			else
			{
				$this->redirect();
			}
		}
		
		/*	**	*/
	}


	/*		FIN CLASS CONTROLLER CATEGORIA		*/