/* Aqui estan las variables que usarán todos los archivos JS */

var sub_carpeta = '/somatec.com/public';
var root = location.protocol + '//' + location.host + sub_carpeta;

//real_time
var pregunta_sleep = 2000;
var notificaion_sleep = 1000;