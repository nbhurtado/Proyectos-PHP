<?php

	require_once __DIR__ . '/../vendor/autoload.php';


	use SoMaTec\Config\VariablesGlobales;
	use SoMaTec\Core\ControladorFrontal;

	$con = new ControladorFrontal();
	
	if(isset($_GET["controller"]))
	{
		$controllerObj = $con->cargarControlador($_GET["controller"]);
		$con->lanzarAccion($controllerObj);
	}
	else
	{
	    $controllerObj = $con->cargarControlador(VariablesGlobales::$controlador_defecto);
		$con->lanzarAccion($controllerObj);
	}
	