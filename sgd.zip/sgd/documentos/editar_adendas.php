<!DOCTYPE html>
<html>
<head>
	<title>Editar Adendas</title>
	<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
	<link rel="stylesheet" href="../documentos/css/editar.css">
	<link rel="stylesheet" href="../css/styles2.css">
</head>
<body>
	<?php 

		include('../documentos/encabezado.php');
		require('conexion.php');

		if(isset($_POST['editar']) && !empty($_POST['nro_registro']) && !empty($_POST['fecha_registro']) && !empty($_POST['dni_ruc']) && !empty($_POST['usuario_entidad']) && !empty($_POST['nro_adenda'])
			&& !empty($_POST['folio']) && !empty($_POST['descripcion']))
		{
			$nro_registro = $_POST['nro_registro'];
			$fecha_registro = $_POST['fecha_registro'];
			$dni_ruc = $_POST['dni_ruc'];
			$usuario_entidad = $_POST['usuario_entidad'];
			$nro_adenda = $_POST['nro_adenda'];
			$folio = $_POST['folio'];
			$descripcion = $_POST['descripcion'];
			$id = $_GET['id'];
			$sql = "UPDATE adendas SET nro_registro = '$nro_registro', fecha_registro = '$fecha_registro', dni_ruc = '$dni_ruc', usuario_entidad = '$usuario_entidad', nro_adenda = '$nro_adenda', folio = '$folio', descripcion = '$descripcion' where id = " . $id;

			if (!mysql_query($sql,$miconex)) 
			{?>
				
				<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span><?php  die("No se pudo editar la adenda [".mysql_error($miconex)."]");?></div><?php
			}
			?><div class="alert alert-info" role="alert"><?php echo "Adenda editado con exito. ".mysql_affected_rows($miconex)." fila(s) insertada(s)";?> </div><?php	
		}

	?> 
		<h2>Editar Adenda</h2>
		
		<form action="<?php echo $_SERVER['PHP_SELF'] . '?id=' . $_GET['id']?>" method="POST">
			<?php 

				$sql = "SELECT * FROM adendas where id = " . $_GET['id'];

				$resultado = mysql_query($sql,$miconex);

				while ($fila = mysql_fetch_assoc($resultado)) 
				{			

					echo "<p><div class='form-group'>
			        <label class='control-label col-xs-9 col-md-2'>Registro N° : </label>
			        <div class='col-xs-9 col-md-2'>
			            <input type='text' name='nro_registro' class='form-control' value='$fila[nro_registro]' maxlength='10' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;''>
			        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Fecha Registro : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='fecha_registro' class='form-control' value='$fila[fecha_registro]'>
				        </div>
				    </div>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-1'>DNI o RUC : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='dni_ruc' class='form-control' maxlength='10' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;' value='$fila[dni_ruc]'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Usuario o Entidad Nº: </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='usuario_entidad' class='form-control' maxlength='100' value='$fila[usuario_entidad]'>
				        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>N° Adenda: </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='nro_adenda' class='form-control' maxlength='100' value='$fila[nro_adenda]'>
				        </div>
				    </div>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-1'>Folio : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='folio' class='form-control' maxlength='4' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;' value='$fila[folio]'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Descripción : </label>
				        <div class='col-xs-9 col-md-9'>
				            <input type='text' class='form-control' name='descripcion' rows='3' cols='100' value='$fila[descripcion]'>
				        </div>
				    </div></p><br><br><br>";	
				}
			?>
			<center><input type="submit" value="Guardar Cambios" class="btn btn-danger" name="editar">
		</form>
		<a href="../documentos/menu.php"><img class="img-rounded" src="../imagenes/regresar.png" width="50" height="50"></a>

</body>
</html>