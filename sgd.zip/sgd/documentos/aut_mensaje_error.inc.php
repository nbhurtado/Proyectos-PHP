<?
$error_login_ms[0]="No se pudo conectar con Base de datos Usuarios";
$error_login_ms[1]="No se pudo realizar consulta a la Base de datos Usuarios";
$error_login_ms[2]="Password � Usuario no existe";
$error_login_ms[3]="Password no valida";
$error_login_ms[4]="Usuario no existe";
$error_login_ms[5]="No est� autorizado para realizar esta acci�n o entrar en esta p�gina";
$error_login_ms[6]="Acceso no autorizado! Registrese";
$error_login_ms[7]="No hay Datos Enviados...";
$error_login_ms[8]="No Coinciden Los tipos de Usuarios...";
?>
