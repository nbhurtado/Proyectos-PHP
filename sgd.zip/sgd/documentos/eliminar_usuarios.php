<!DOCTYPE html>
<html>
<head>
	<title>Eliminar Resoluciones</title>
		<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
		<link rel="stylesheet" href="../documentos/css/estilos.css">
		<link rel="stylesheet" href="../css/styles2.css">
</head>
<body>
	<?php 
		include('../documentos/encabezado.php');
		require('conexion.php');

		if(isset($_GET['id']))
		{
			$sql = "delete from usuarios where id = " . $_GET['id'];

			if (!mysql_query($sql,$miconex))  
			{?>
				
				<center><div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span><?php  die("No se pudo eliminar al usuario [".mysql_error($miconex)."]");?></div><?php
			}
			?><center><div class="alert alert-info" role="alert"><?php echo "Usuario eliminado con exito. ".mysql_affected_rows($miconex)." fila(s) eliminada(s)";?> </div><?php		
		}
		echo "<META HTTP-EQUIV=Refresh CONTENT='0;URL=../documentos/menu.php'>";
	?>
</body>
</html>