<?	
session_start();
if (session_is_registered("usuario"))
{
	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title> SGD</title>
<script type="text/javascript" src="menuadmin/stmenu.js"></script>
<style type="text/css">
<!--
.Estilo1 {
	font-family: Arial;
	font-size: 11px;
	color: #FF0000;
	font-weight: bold;
}
.Estilo2 {
	font-family: Arial;
	font-size: 11px;
	font-weight: bold;
	color: #6633FF;
}
-->
</style>
</head>

<body>
<div align="center">
	<? $stime=date("d-m-Y H:i:s");$fecha_actual=date("d")."  de  ".date("m")."  del  ".date("Y");
	$fecha_ingreso=$fecha_actual; ?><img src="../imagenes/usuario.png" width="40" height="40" /> <span class="Estilo1">Usuario:</span><span class="Estilo2">      
    <?=$usuario ?>&nbsp;&nbsp;<span class="Estilo1">Fecha del Sistema:</span><span class="Estilo2"> <? echo $fecha_ingreso ?></span>
</div>
</body>
</html>
<?php
}else{
include("vigilante.php"); 
}
?>