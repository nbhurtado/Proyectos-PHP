<?	
session_start();
if (session_is_registered("usuario"))
{
?>
<?php 
	include("../documentos/encabezado2.php"); include("menuadmin.php");
 	require("conexion.php");
 ?>
	<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
	<link rel="stylesheet" href="../documentos/css/estilos.css">
	<link rel="stylesheet" href="../css/styles2.css">
	<script src="js/validar.js" type="text/javascript" language="javascript"></script>

<body class="cuerpo">
	<?php 
		if (isset($_POST['agregar']) && !empty($_POST['id']) && !empty($_POST['nombre_usuario']) && !empty($_POST['password_usuario']) && !empty($_POST['tipo_usuario']) && !empty($_POST['nombres']) && !empty($_POST['apellidos']) 
			&& !empty($_POST['cargo'])) 
		{
			$id=$_POST['id'];
			$nombre_usuario=$_POST['nombre_usuario'];
			$password_usuario=$_POST['password_usuario'];
			$tipo_usuario=$_POST['tipo_usuario'];
			$nombres=$_POST['nombres'];
			$apellidos=$_POST['apellidos'];
			$cargo=$_POST['cargo'];
			$sql="INSERT INTO usuarios VALUES ('$id','$nombre_usuario','$password_usuario','$tipo_usuario','$nombres','$apellidos','$cargo')";
			if (!mysql_query($sql,$miconex)) 
			{?>
				
				<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span><?php  die("No se pudo insertar la adenda [".mysql_error($miconex)."]");?></div><?php
			}
			?><div class="alert alert-info" role="alert"><?php echo "Usuario agregado con exito. ".mysql_affected_rows($miconex)." fila(s) insertada(s)";?> </div><?php			
		}
	?>
	<article>
	<h4><img src="../imagenes/agregar.png" width="50" height="50">Agregar Usuarios </h4><hr>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<div role="tabpanel" class="tab-pane">
				<form class="form-horizontal" >
			    <p><div class="form-group" style='display:none;'>
			        <label class="control-label col-xs-9 col-md-2">ID Usuario : </label>
			        <div class="col-xs-9 col-md-2">		
			        <?php  	
			        	$id=GenerarCodigo("usuarios","id", $miconex);
            		?>	        	
			            <input type="text" name="id" class="form-control" value="<?=$id?>">
			        </div>
			    </div>
			    <p><div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Nombre de usuario: </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="nombre_usuario" class="form-control" placeholder="Ingrese un nombre de usuario" maxlength="10" required>
			        </div>
			    </div>
			    <div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Contraseña de usuario:</label>
			        <div class="col-xs-9 col-md-2">
			            <input type="password" name="password_usuario" class="form-control" placeholder="Ingrese su contraseña" required>
			        </div>
			    </div>
			    <div class="form-group">
			        <label class="control-label col-xs-9 col-md-1">Tipo : </label>
			        <div class="col-xs-9 col-md-2">
			          <select name="tipo_usuario" class="form-control" >
			          	<option value="A">Administrador</option>
			          	<option value="U" selected>Usuario</option>
            		  </select>
			        </div>
			    </div></p><br><br>
			    <!--<div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Tipo : </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="tipo_usuario" class="form-control" placeholder="Ingrese su tipo" maxlength="1" required>
			        </div>
			    </div></p><br><br>-->
			    <p><div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Nombres : </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="nombres" class="form-control" placeholder="Ingrese su Nombre" maxlength="100" required>
			        </div>
			    </div>
			    <div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Apellidos: </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="apellidos" class="form-control" placeholder="Ingrese su Apellido" maxlength="100" required>
			        </div>
			    </div>
			    <div class="form-group">
			        <label class="control-label col-xs-9 col-md-1">Cargo: </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="cargo" class="form-control" placeholder="Ingrese su cargo" required>
			        </div>
			    </div></p><br><br>
				<center class="col-xs-9">
				    <div class="form-group">
						<!--Mantenimiento-->
						<input type="submit" class="btn btn-primary" name="agregar" value="Registrar">
						<input type="reset" class="btn btn-success" name="nuevo" value="Nuevo">
					</div>
				</center>
			    </form>
		</div>
	</form><br><br><br>
	<?php
		echo "<div class='panel panel-default'>";
		/**/
			$link=$miconex;
			$tabla="usuarios";
			$sql="SELECT id as 'ID', nombre_usuario as 'Usuario', password_usuario as 'Password', tipo_usuario as 'Tipo', nombres as 'Nombres',apellidos as 'Apellidos', cargo as 'Cargo' FROM usuarios";
			//$sql="select * from contratos where tipo_contrato=1";
			$rs=mysql_query($sql,$link) or die ("Error : " . mysql_error());
			paginar(10,$sql, $tabla,"Lista de Usuarios",1,$PHP_SELF);
		/**/
		//cerrar conexion con BD
		mysql_close($miconex);
		?>
		<?php echo "<br><br>"; 
	?></article>
	<?php include("../pie.php"); ?>
</body>
</html>
<?php
}else{
include("vigilante.php"); 
}
?>