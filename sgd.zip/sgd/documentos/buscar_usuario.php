<?	
session_start();
if (session_is_registered("usuario"))
{
?>

<?php 
	include("../documentos/encabezado2.php"); include("menuadmin.php");	
 	require("conexion.php");
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Buscador</title>
	<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
	<link rel="stylesheet" href="../documentos/css/estilo.css">
	<link rel="stylesheet" href="../css/styles2.css">
</head>
<body class="cuerpo2">
<center>
		<aside class="formulario">
		<img src="../imagenes/buscar.png" width="50" height="50">
		<div class="form-group">
			<form action="<?php echo $_SERVER['PHP_SELF']?>" method="POST">
			
			<div class="col-md-3">
				<select name="tipo" id="tipo" class="form-control"><h4><img src="../imagenes/buscar.png" width="50" height="50">Buscar</h4>
					<option value="nombre_usuario">Usuarios</option>
					<option value="nombres">Nombre </option>
				</select>
			</div>
				<div class="col-md-3">
					<input type="text" name="buscar_texto" class="form-control" required>
				</div>
				<div class="col-md-3">
					<input type="submit" class="btn btn-default" value="Buscar" name="buscar">
				</div>
			</form><br><hr>
		</div>
		</aside>

		<section class="resultado">
			<?php echo "<div class='panel panel-default'>";

				if(isset($_POST['buscar']) && !empty($_POST['buscar_texto']) && !empty($_POST['tipo']))
				{
					

					$consulta = "SELECT * FROM usuarios WHERE nombre_usuario =" .$_POST['tipo'] . " LIKE '%" . $_POST['buscar_texto'] . "%'";
					
					if(! $resultado = mysql_query($consulta,$miconex))
					{
						die('Ocurrio un error en la consulta [' . mysql_error($miconex) . "]");
					}

					echo "<h2>Lista de Usuarios</h2>";

					if(mysql_num_rows($resultado)>0)
					{

						?><button class="btn btn-primary" type="button">Cantidad de usuarios Encontratos: <span class="badge"><?php  echo " ".mysql_num_rows($resultado)."<br>"; ?></span></button><br><br>

						<?php 
						while ($fila=mysql_fetch_assoc($resultado))
						{
							echo "<p><div class='form-group'>
			        <label class='control-label col-xs-9 col-md-2'>Nombre de Usuarios : </label>
			        <div class='col-xs-9 col-md-2'>
			            <input type='text' name='nombre_usuario' class='form-control' value='$fila[nombre_usuario]' maxlength='10' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;'' readonly='readonly'>
			        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Password de usuario : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='password_usuario' class='form-control' value='$fila[password_usuario]' readonly='readonly'>
				        </div>
				    </div>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-1'>Tipo de usuario : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='tipo_usuario' class='form-control' maxlength='10' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;' value='$fila[tipo_usuario]' readonly='readonly'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Nombres :</label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='nombres' class='form-control' maxlength='100' value='$fila[nombres]' readonly='readonly'>
				        </div>
				    </div>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Apellidos : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='apellidos' class='form-control' maxlength='4' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;' value='$fila[apellidos]' readonly='readonly'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Cargo : </label>
				        <div class='col-xs-9 col-md-9'>
				            <input type='text' class='form-control' name='cargo' rows='3' cols='100' value='$fila[cargo]' readonly='readonly'>
				        </div>
				    </div></p><br><hr><br><br>";
				
						}
						echo "</div></table><hr>";
					}
					else
					{
						echo "No hay usuarios para mostrar";
					}
				}

			?>
		</section></center>
		<?php 
			mysql_close($miconex);
			include('../pie.php');
		?>
</body>
</html>
<?php
}else{
include("vigilante.php"); 
}
?>