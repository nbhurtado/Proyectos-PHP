<head>
<link href="../css/styles.css" rel="stylesheet" type="text/css">
</head>
<table width="383" border="0" align="center">
  <tr>
    <td width="56">&nbsp;</td>
    <td width="104">&nbsp;</td>
    <td width="26">&nbsp;</td>
  </tr>
  <tr>
    <td><img src="../imagenes/ingresar.png" width="51" height="53" border="0" /></td>
    <td colspan="2" class="newlink2">Esta intentando ingresar de forma Ilicita a esta pagina, por favor Ingrese correctamente...</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>


<?php
    //echo  "Ingrese correctamente a esta pagina...";
    echo "<META HTTP-EQUIV=Refresh CONTENT='1;URL=../documentos/login.php'>";
    exit;
//header("location: ../index.php");
?>