<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>SGD</title>
	<link rel="icon" type="image/png" href="../imagenes/icono.png" />
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" href="../css/estilos_admin.css">
	<link rel="stylesheet" href="../fonts.css">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<script src="http://code.jquery.com/jquery-latest.js"></script>
	<script src="../jquery/main.js"></script>
</head>
	<header class="menu_general admin">
		<div class="menu_bar">
			<a href="#" class="bt-menu"><span class="icon-list2"></span>Menú</a>
		</div>
 
		<nav>
			<ul>
				<li><a href="menu.php"><span class="icon-home"></span>Inicio</a></li>
				<li class="submenu">
					<a href="#"><span class="icon-suitcase"></span>Contratos<span class="caret icon-arrow-down6"></span></a>
					<ul class="children">
						<li><a href="contrato_gerencial.php"> <span class="icon-keyboard"></span> Gerencial </a></li>
						<li><a href="contrato_directoral.php"> <span class="icon-keyboard"></span> Directoral </a></li>
						<li><a href="contrato_presidencial.php"> <span class="icon-keyboard"></span> Presidencial </a></li>
					</ul>
				</li>
				<li class="submenu">
					<a href="#"><span class="icon-briefcase"></span>Convenios<span class="caret icon-arrow-down6"></span></a>
					<ul class="children">
						<li><a href="convenio_presidencial.php"> <span class="icon-keyboard"></span> Presidenciales </a></li>
						<li><a href="convenio_gerencial.php"> <span class="icon-keyboard"></span> Gerenciales </a></li>
					</ul>
				</li>
				<li class="submenu">
					<a href="#"><span class="icon-layers"></span>Adendas<span class="caret icon-arrow-down6"></span></a>
					<ul class="children">
						<li><a href="adenda_cgerencial.php"> <span class="icon-keyboard"></span> Adendas de contratos Gerenciales </a></li>
						<li><a href="adenda_cdirectoral.php"> <span class="icon-keyboard"></span> Adendas de contratos Directorales </a></li>
						<li><a href="adenda_cpresidencial.php"> <span class="icon-keyboard"></span> Adendas de contratos Presidenciales </a></li>
						<li><a href="adenda_ccpresidencial.php"> <span class="icon-keyboard"></span> Adendas de convenios Presidenciales </a></li>
						<li><a href="adenda_ccgerencial.php"> <span class="icon-keyboard"></span> Adendas de convenios Gerenciales </a></li>
					</ul>
				</li>
				<li class="submenu">
					<a href="#"><span class="icon-archive"></span>Resoluciones<span class="caret icon-arrow-down6"></span></a>
					<ul class="children">
						<li><a href="resolucion_presidencial.php"> <span class="icon-keyboard"></span> Presidencial </a></li>
						<li><a href="resolucion_ggeneral.php"> <span class="icon-keyboard"></span> Gerencia General </a></li>
						<li><a href="resolucion_infraestructura.php"> <span class="icon-keyboard"></span> Infraestructura </a></li>
						<li><a href="resolucion_deconomico.php"> <span class="icon-keyboard"></span> Desarrollo Economico </a></li>
						<li><a href="resolucion_rnaturales.php"> <span class="icon-keyboard"></span> Recursos Naturales </a></li>
						<li><a href="resolucion_dsocial.php"> <span class="icon-keyboard"></span> Desarrollo Social </a></li>
						<li><a href="resolucion_planificacion.php"> <span class="icon-keyboard"></span> Planificacion </a></li>
						<li><a href="resolucion_directoral.php"> <span class="icon-keyboard"></span> Directoral </a></li>
					</ul>
				</li>
				<li class="submenu">
					<a href="#"><span class="icon-archive"></span>Buscar<span class="caret icon-arrow-down6"></span></a>
					<ul class="children">
						<li><a href="buscar_documentos.php"> <span class="icon-keyboard"></span> Contratos </a></li>
						<li><a href="buscar_convenios.php"> <span class="icon-keyboard"></span> Convenios </a></li>
						<li><a href="buscar_adendas.php"> <span class="icon-keyboard"></span> Adendas </a></li>
						<li><a href="buscar_resoluciones.php"> <span class="icon-keyboard"></span> Resoluciones </a></li>
					</ul>
				</li>
				<li class="submenu">
					<a href="#"><span class="icon-archive"></span>Administrar SGD<span class="caret icon-arrow-down6"></span></a>
					<ul class="children">
						<li><a href="agregar_usuario.php"> <span class="icon-keyboard"></span> Usuarios </a></li>
						<li><a href="buscar_usuario.php"> <span class="icon-keyboard"></span> Buscar Usuarios </a></li>
						<li><a href="../documentos/estadistica/index.php"> <span class="icon-keyboard"></span> Ver Reporte Estadístico </a></li>
						<li><a href="reportes.php"> <span class="icon-keyboard"></span> Ver Reporte</a></li>
					</ul>
				</li>
				<li><a href="logout.php"><span class="icon-user"></span>Cerrar Sesion</a></li>
			</ul>
		</nav>
	</header>