<!doctype html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Reportes</title>
	<link rel="stylesheet" href="../css/estilos_reportes.css">
	<script src="../jquery/script.js"></script>
	<script src="../jquery/jquery.js"></script>
	<link rel="icon" type="image/png" href="../imagenes/icono.png" />
</head>
<body>

	<div id="titulo">
		<p id="header">Reportes</p>
		<p id="subheader">Elija la tabla para detallar el reporte </p>
		<p class="buscador">
			<td><input type="date" id="bd-desde"/></td>
            <td>Hasta&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td><input type="date" id="bd-hasta"/></td>
		</p>
	</div>

	<header>

		<a  href="javascript:reportePDF();"><div class="contenedor" id="uno">
			<img class="icon" src="../imagenes/icon2.png">
			<p class="texto">Contratos</p>
		</div></a>

		<a target="_blank" href="javascript:reportePDF();"><div class="contenedor" id="dos">
			<img class="icon" src="../imagenes/icon2.png">
			<p class="texto">Convenios</p>
		</div></a>

		<a href="javascript:reportePDF();"><div class="contenedor" id="tres">
			<img class="icon" src="../imagenes/icon2.png">
			<p class="texto">Adendas</p>
		</div></a>

		<a href="javascript:reportePDF();"><div class="contenedor" id="cuatro">
			<img class="icon" src="../imagenes/icon2.png">
			<p class="texto">Resoluciones</p>
		</div></a><hr><hr>

	</header>
		<p id="subheader">Presione la imagen para volver al SGD </p>
		<a href="../documentos/menu_admin.php"><div><img class="icon" src="../imagenes/icono.png"></div></a>

</body>
</html>
