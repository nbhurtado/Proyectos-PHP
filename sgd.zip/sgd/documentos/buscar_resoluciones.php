<?	
session_start();
if (session_is_registered("usuario"))
{
?>

<?php 
	include("../documentos/encabezado.php"); include("menuadmin.php");	
 	require("conexion.php");
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Buscador</title>
	<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
	<link rel="stylesheet" href="../documentos/css/estilo.css">
	<link rel="stylesheet" href="../css/styles2.css">
</head>
<body class="cuerpo2">
<center>
		<aside class="formulario">
		<img src="../imagenes/buscar.png" width="50" height="50">
		<div class="form-group">
			<form action="<?php echo $_SERVER['PHP_SELF']?>" method="POST">
			
			<div class="col-md-3">
				<select name="tipo" id="tipo" class="form-control"><h4><img src="../imagenes/buscar.png" width="50" height="50">Buscar</h4>
					<option value="sige">SIGE</option>
					<option value="fecha_registro">Fecha Registro</option>
				</select>
			</div>
			<div class="col-md-3">
				<select name="tipo2" id="tipo2" class="form-control"><h4><img src="../imagenes/buscar.png" width="50" height="50">Buscar</h4>
					<option value="1">Resolución Presidencial</option>
					<option value="2">Resolución Gerencia General</option>
					<option value="3">Resolución Infraestructura</option>
					<option value="4">Resolución Desarrollo Económico</option>
					<option value="5">Resolución Recursos Naturales</option>
					<option value="6">Resolución Desarrollo Social</option>
					<option value="7">Resolución Planificación</option>
					<option value="8">Resolución Directoral</option>
				</select>
			</div>
				<div class="col-md-3">
					<input type="text" name="buscar_texto" class="form-control" required>
				</div>
				<div class="col-md-3">
					<input type="submit" class="btn btn-default" value="Buscar" name="buscar">
				</div>
			</form><br><hr>
		</div>
		</aside>

		<section class="resultado">
			<?php echo "<div class='panel panel-default'>";

				if(isset($_POST['buscar']) && !empty($_POST['buscar_texto']) && !empty($_POST['tipo']))
				{
					

					$consulta = "SELECT * FROM resoluciones WHERE tipo_resolucion =" .$_POST['tipo2']. " and " . $_POST['tipo'] . " LIKE '%" . $_POST['buscar_texto'] . "%'";
					
					if(! $resultado = mysql_query($consulta,$miconex))
					{
						die('Ocurrio un error en la consulta [' . mysql_error($miconex) . "]");
					}

					echo "<h2>Lista de Resoluciones</h2>";

					if(mysql_num_rows($resultado)>0)
					{

						?><button class="btn btn-primary" type="button">Cantidad de documentos Encontratos: <span class="badge"><?php  echo " ".mysql_num_rows($resultado)."<br>"; ?></span></button><br><br>

						<?php 
						while ($fila=mysql_fetch_assoc($resultado))
						{
							echo "<p><div class='form-group'>
			        <label class='control-label col-xs-9 col-md-2'>Registro N° : </label>
			        <div class='col-xs-9 col-md-2'>
			            <input type='text' name='nro_registro' class='form-control' value='$fila[nro_registro]' maxlength='10' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;'' readonly='readonly'>
			        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Fecha Registro : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='fecha_registro' class='form-control' value='$fila[fecha_registro]' readonly='readonly'>
				        </div>
				    </div>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-1'>SIGE : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='sige' class='form-control' maxlength='10' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;' value='$fila[sige]' readonly='readonly'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>N° Resolución Ejecut.:</label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='nro_resolucion_ejecutiva' class='form-control' maxlength='100' value='$fila[nro_resolucion_ejecutiva]' readonly='readonly'>
				        </div>
				    </div>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-1'>Folio : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='folio' class='form-control' maxlength='4' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;' value='$fila[folio]' readonly='readonly'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Descripción : </label>
				        <div class='col-xs-9 col-md-9'>
				            <input type='text' class='form-control' name='descripcion' rows='3' cols='100' value='$fila[descripcion]' readonly='readonly'>
				        </div>
				    </div></p><br><br><br>";
				
						}
						echo "</div></table><hr>";
					}
					else
					{
						echo "No hay resoluciones para mostrar";
					}
				}

			?>
		</section></center>
		<?php 
			mysql_close($miconex);
			include('../pie.php');
		?>
</body>
</html>
<?php
}else{
include("vigilante.php"); 
}
?>