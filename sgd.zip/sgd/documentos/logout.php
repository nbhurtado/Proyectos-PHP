<?php
// iniciamos sesiones
session_start();
// destruimos la session de usuarios y variables usadas.
$usuarios_sesion = "admin";
session_name($usuarios_sesion);
session_unset();
session_destroy();
echo "<META HTTP-EQUIV=Refresh CONTENT='1;URL=login.php'>";  
?>

<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no, minimal-ui">
		<link rel="stylesheet" media="screen" href="../css/estilos.css">
	</head>
<body class="cerrar"><br><br><br><br><br><br>>
	<center> 
	  	<font face="Arial" size="10"></font>
	  	<h3>Cerrando sesion de Usuario, Espere un momento ... </h3>
	  	<img src="../imagenes/load.gif">
	</center>
</body>
</html>
