<!DOCTYPE html>
<html>
<head>
	<title>Editar Adendas</title>
	<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
	<link rel="stylesheet" href="../documentos/css/editar.css">
	<link rel="stylesheet" href="../css/styles2.css">
</head>
<body>
	<?php 

		include('../documentos/encabezado2.php');
		require('conexion.php');

		if(isset($_POST['editar']) && !empty($_POST['nombre_usuario']) && !empty($_POST['password_usuario']) && !empty($_POST['tipo_usuario']) && !empty($_POST['nombres'])
			&& !empty($_POST['apellidos']) && !empty($_POST['cargo']))
		{
			$nombre_usuario = $_POST['nombre_usuario'];
			$password_usuario = $_POST['password_usuario'];
			$tipo_usuario = $_POST['tipo_usuario'];
			$nombres = $_POST['nombres'];
			$apellidos = $_POST['apellidos'];
			$cargo = $_POST['cargo'];
			$id = $_GET['id'];
			$sql = "UPDATE usuarios SET nombre_usuario = '$nombre_usuario', password_usuario = '$password_usuario', tipo_usuario = '$tipo_usuario', nombres = '$nombres',
									apellidos = '$apellidos', cargo = '$cargo' where id = " . $id;

			if (!mysql_query($sql,$miconex)) 
			{?>
				
				<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span><?php  die("No se pudo editar la resolucion [".mysql_error($miconex)."]");?></div><?php
			}
			?><div class="alert alert-info" role="alert"><?php echo "Resolucion editado con exito. ".mysql_affected_rows($miconex)." fila(s) insertada(s)";?> </div><?php	
		}

	?> 
		<h2>Editar Resoluciones Presidenciales</h2>
		
		<form action="<?php echo $_SERVER['PHP_SELF'] . '?id=' . $_GET['id']?>" method="POST">
			<?php 

				$sql = "SELECT * FROM usuarios where id = " . $_GET['id'];

				$resultado = mysql_query($sql,$miconex);

				while ($fila = mysql_fetch_assoc($resultado)) 
				{			

					echo "<p><div class='form-group'>
			        <label class='control-label col-xs-9 col-md-2'>Usuario : </label>
			        <div class='col-xs-9 col-md-2'>
			             <input type='text' name='nombre_usuario' class='form-control' value='$fila[nombre_usuario]' maxlength='10' required>
			        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Contraseña : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='password_usuario' class='form-control' value='$fila[password_usuario]'>
				        </div>
				    </div>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-1'>Tipo de Usuario : </label>
				        <div class='col-xs-9 col-md-1'>
				            <input type='text' name='tipo_usuario' class='form-control' maxlength='30' value='$fila[tipo_usuario]'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Nombres: </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='nombres' class='form-control' maxlength='100' value='$fila[nombres]'>
				        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Apellidos : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='apellidos' class='form-control' value='$fila[apellidos]'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Cargo : </label>
				        <div class='col-xs-9 col-md-8'>
				            <input type='text' class='form-control' name='cargo' rows='3' cols='100' value='$fila[cargo]'>
				        </div>
				    </div></p><br><br><br>";	
				}
			?>
			<center><input type="submit" value="Guardar Cambios" class="btn btn-danger" name="editar">
		</form>
		<a href="../documentos/menu2.php"><img class="img-rounded" src="../imagenes/regresar.png" width="50" height="50"></a>

</body>
</html>