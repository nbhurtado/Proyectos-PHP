<?php
$conexion = mysql_connect('127.0.0.1', 'root', '123456');
mysql_select_db('documentos', $conexion);
?>