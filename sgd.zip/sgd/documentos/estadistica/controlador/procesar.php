<?php
	include('conexion.php');
	
	$año = $_POST['año']; 
	$tipo = $_POST['tipo'];
	$enero = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=1 AND YEAR(fecha_registro)='$año'"));
	$febrero = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=2 AND YEAR(fecha_registro)='$año'"));
	$marzo = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=3 AND YEAR(fecha_registro)='$año'"));
	$abril = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=4 AND YEAR(fecha_registro)='$año'"));
	$mayo = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=5 AND YEAR(fecha_registro)='$año'"));
	$junio = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=6 AND YEAR(fecha_registro)='$año'"));
	$julio = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=7 AND YEAR(fecha_registro)='$año'"));
	$agosto = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=8 AND YEAR(fecha_registro)='$año'"));
	$septiembre = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=9 AND YEAR(fecha_registro)='$año'"));
	$octubre = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=10 AND YEAR(fecha_registro)='$año'"));
	$noviembre = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=11 AND YEAR(fecha_registro)='$año'"));
	$diciembre = mysql_fetch_array(mysql_query("SELECT SUM(tipo_adenda) AS r FROM adendas WHERE MONTH(fecha_registro)=12 AND YEAR(fecha_registro)='$año'"));
	
	$data = array(0 => round($enero['r'],1),
				  1 => round($febrero['r'],1),
				  2 => round($marzo['r'],1),
				  3 => round($abril['r'],1),
				  4 => round($mayo['r'],1),
				  5 => round($junio['r'],1),
				  6 => round($julio['r'],1),
				  7 => round($agosto['r'],1),
				  8 => round($septiembre['r'],1),
				  9 => round($octubre['r'],1),
				  10 => round($noviembre['r'],1),
				  11 => round($diciembre['r'],1)
				  );			 
	echo json_encode($data);
?>