<?	
session_start();
if (session_is_registered("usuario"))
{
?>
<?php 
	include("../documentos/encabezado.php"); include("menuadmin.php");
 	require("conexion.php");
 ?>
	<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
	<link rel="stylesheet" href="../documentos/css/estilos.css">
	<link rel="stylesheet" href="../css/styles2.css">
<body class="cuerpo">
	<?php 
		if (isset($_POST['agregar']) && !empty($_POST['id']) && !empty($_POST['tipo_contrato']) && !empty($_POST['nro_registro']) && !empty($_POST['fecha_registro']) && !empty($_POST['dni_ruc']) && !empty($_POST['usuario_entidad']) && !empty($_POST['nro_contrato']) 
			&& !empty($_POST['dependencia']) && !empty($_POST['cargo']) && !empty($_POST['folio']) && !empty($_POST['descripcion']) && !empty($_POST['fecha_inicio']) && !empty($_POST['fecha_fin'])) 
		{
			$id=$_POST['id'];
			$tipo_contrato=$_POST['tipo_contrato'];
			$nro_registro=$_POST['nro_registro'];
			$fecha_registro=$_POST['fecha_registro'];
			$dni_ruc=$_POST['dni_ruc'];
			$usuario_entidad=$_POST['usuario_entidad'];
			$nro_contrato=$_POST['nro_contrato'];
			$dependencia=$_POST['dependencia'];
			$cargo=$_POST['cargo'];
			$folio=$_POST['folio'];
			$descripcion=$_POST['descripcion'];
			$fecha_inicio=$_POST['fecha_inicio'];
			$fecha_fin=$_POST['fecha_fin'];
			$sql="INSERT INTO contratos VALUES ('$id','$tipo_contrato','$nro_registro','$fecha_registro','$dni_ruc','$usuario_entidad','$nro_contrato','$dependencia','$cargo','$folio','$descripcion','$fecha_inicio','$fecha_fin')";
			if (!mysql_query($sql,$miconex)) 
			{?>
				
				<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span><?php  die("No se pudo insertar el contrato [".mysql_error($miconex)."]");?></div><?php
			}
			?><div class="alert alert-info" role="alert"><?php echo "Contrato agregado con exito. ".mysql_affected_rows($miconex)." fila(s) insertada(s)";?> </div><?php			
		}
	?>
	<article>
	<h4><img src="../imagenes/agregar.png" width="50" height="50">Agregar Contrato Gerencial</h4>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<div role="tabpanel" class="tab-pane">
				<form class="form-horizontal">
			    <p><div class="form-group" style='display:none;'>
			        <label class="control-label col-xs-2">ID Contrato : </label>
			        <div class="col-xs-2">
			        <?php  	
			        	$id=GenerarCodigo("contratos","id", $miconex);
            		?>
			        	
			            <input type="text" name="id" class="form-control" value="<?=$id?>">
			        </div>
			    </div>
			    <div class="form-group" style='display:none;'>
			        <label class="control-label col-xs-2">Tipo Contrato : </label>
			        <div class="col-xs-2">
			            <input type="text" name="tipo_contrato" class="form-control" value="1">
			        </div>
			    </div></p><br><br>
			    <p><div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Registro N° : </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="nro_registro" class="form-control" placeholder="Ingrese N° de Registro" maxlength="10" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" required>
			        </div>
			    </div>
			    <div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Fecha Registro : </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="date" name="fecha_registro" class="form-control">
			        </div>
			    </div>
			    <div class="form-group">
			        <label class="control-label col-xs-9 col-md-1">DNI/RUC:</label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="dni_ruc" class="form-control" placeholder="Ingrese N° DNI">
			        </div>
			    </div></p><br><br>
			    <p><div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Usuario o Entidad N° : </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="usuario_entidad" class="form-control" placeholder="Ingrese Usuario o Entidad" maxlength="100" required>
			        </div>
			    </div>
			    <div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Contrato Gerencial N°:</label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="nro_contrato" class="form-control" placeholder="N° Contrato Gerencial" maxlength="100" required>
			        </div>
			    </div>
			    <div class="form-group">
			        <label class="control-label col-xs-9 col-md-1">Dependencia: </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="dependencia" class="form-control" placeholder="Ingrese la dependencia" maxlength="100" required>
			        </div>
			    </div></p><br><br>
			    <p><div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Cargo : </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="cargo" class="form-control" placeholder="Ingrese el cargo" maxlength="100" required>
			        </div>
			    </div>
			    <div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Folio : </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="text" name="folio" class="form-control" placeholder="Ingrese el folio" maxlength="4" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" required>
			        </div>
			    </div></p><br><br>
			    <p><div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Descripción : </label>
			        <div class="col-xs-9 col-md-9">
			            <textarea class="form-control" name="descripcion" rows="3" cols="100" placeholder="Ingrese una descripción" required></textarea>
			        </div>
			    </div></p><br><br><br>
			    <p><div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Fecha Inicio de Contrato : </label>
			        <div class="col-xs-9 col-md-2">
			            <input type="date" name="fecha_inicio" class="form-control">
			        </div>
			    </div>
			    <div class="form-group">
			        <label class="control-label col-xs-9 col-md-2">Fecha Final de Contrato:</label>
			        <div class="col-xs-9 col-md-2">
			            <input type="date" name="fecha_fin" class="form-control">
			        </div>
			    </div></p><br><br><br>
				<center class="col-xs-9">
				    <div class="form-group">
						<!--Mantenimiento-->
						<input type="submit" class="btn btn-primary" name="agregar" value="Registrar">
						<input type="reset" class="btn btn-success" name="nuevo" value="Nuevo">
					</div>
				</center>
			    </form>
		</div>
	</form><br><br>
	<?php
		/**/
			$link=$miconex;
			$tabla="contratos";
			$sql="SELECT id as 'ID', nro_registro as 'N° Registro', fecha_registro as 'Fecha Registro', usuario_entidad as 'Interesado', nro_contrato as 'N° C.G',dependencia as 'Dependencia', cargo as 'Cargo', folio as 'Folio', fecha_inicio as 'Fecha Inicio', fecha_fin as 'Fecha Fin' FROM contratos where tipo_contrato=1";
			//$sql="select * from contratos where tipo_contrato=1";
			$rs=mysql_query($sql,$link) or die ("Error : " . mysql_error());
			paginar(10,$sql, $tabla,"Lista de Contratos",1,$PHP_SELF);
		/**/
		//cerrar conexion con BD
		mysql_close($miconex);
		?>
		<?php echo "<br><br>"; 
	?></article>
	<?php include("../pie.php"); ?>
</body>
</html>
<?php
}else{
include("vigilante.php"); 
}
?>