<?php
session_start();
if (isset($_POST['ingresar'])) 
{
 include("conexion.php");
$link=Conectarse(); 
$usu=trim($_POST['txtuser']);
$clave=trim($_POST['txtclave']);
$tipou=$_POST['cbotipo'];
$sqlver=mysql_query("select * from usuarios where nombre_usuario='$usu' and tipo_usuario='$tipou' ",$link) or die ("Error Usuarios: " . mysql_error() . "Numero " . mysql_errno());
		while($datasql=mysql_fetch_array($sqlver))
		{
			$xidusuario=$datasql[0];
			$xusuario=$datasql['nombre_usuario'];
			$xtipo=$datasql['tipo_usuario'];
			$xclave=$datasql['password_usuario'];
		}
		if (trim($usu) != trim($xusuario)) 
		{
		header("location:login.php?error_login=4");		
		exit;
		}
		if (trim($clave) != trim($xclave)) 
		{
		header("location:login.php?error_login=3");		
		exit;
		}
		if (trim($tipou) != trim($xtipo)) 
		{
		header("location:login.php?error_login=8");		
		exit;
		}

	$usuario=$xusuario;
	session_name("usuario");
	session_register("usuario");
	$usuario2=$xusuario;
	session_name("usuario2");
	session_register("usuario2");
	switch($xtipo)
	{
		case A : 
			header("location:../documentos/menu_admin.php");
			break;
		case U : 
			header("location:../documentos/menu.php");
			break;	
	}
}else{
header("location:index.php?error_login=7");
}
?>