<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>SGD</title>
	<link rel="icon" type="image/png" href="../imagenes/icono.png" />
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/estilos.css">
	<link rel="stylesheet" href="css/estiloslogin.css">
	<link rel="stylesheet" href="../fonts.css">
	<script src="http://code.jquery.com/jquery-latest.js"></script>
	<script src="../jquery/main.js"></script>
<script>
	function buscar(){
		document.location.href = "../documentos/login.php";
	}
</script>
<style type="text/css">
<!--
.Estilo1 {
	color: #006699;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
-->
</style>
<link href="../css/styles.css" rel="stylesheet" type="text/css">
<link href="../css/estilos.css" rel="stylesheet" type="text/css">
</head>

<body>

<form action="verifica.php" method="post" name="frmacceso" id="frmacceso">
<center>
<table class="login" width="387" align="center"  cellspacing="0" class="login">
  <tr> 
    <th colspan="2" class="tabla-top"><center>Login de Usuarios</center></th>
  </tr>
  <tr> 
    <td width="387"  valign="top"><table width="350" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td height="20">&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr class="info"> 
          <td class="info"><img src="../imagenes/tipo.png" width="50" height="50"></td>
          <td class="campo1">&nbsp;Usuario&nbsp;</td>
          <td ><input name="txtuser" type="text" class="form-control"></td>

        </tr>
        <tr> 
          <td><img src="../imagenes/password.png" width="50" height="50"></td>
          <td class="campo1" >&nbsp;Clave&nbsp;</td>
          <td><input name="txtclave" type="password" class="form-control" id="txtclave" size="15" maxlength="15"></td>

        </tr>
        <tr> 
          <td><img src="../imagenes/login.png" width="50" height="50"></td>
          <td class="campo1" >&nbsp;Tipo&nbsp;</td>
          <td ><select name="cbotipo" size="1" class="form-control" id="cbotipo">
              <option value="A">&nbsp;Administrador</option>
              <option value="U" selected>&nbsp;Usuario</option>
            </select></td>
          
        </tr>
      </table></td><tr>
          <td  valign="top" class="new-link" width="164" height="37"> 
	        <!--<table border="0" cellpadding="0" cellspacing="0" align="center">
              <tr> 
                <td width="164" height="37">-->
                      <center><input name="ingresar" type="submit" class="btn btn-primary" id="ingresar" value="Ingresar"></td>
              <!--</tr>
              <!--<tr> 
                <td width="64" height="37"> 
                  <div align="center"> 
                      <input name="Modificar" type="reset" class="btn btn-danger" onClick="buscar();" value="Cancelar" <?php if ($sw==1) { echo disabled;}?>>
                  </div></td>
              </tr>
            </table>-->
	</td>
  </tr>
  <tr> 
    <td height="20"  colspan="2" class="thtitulo">
    <table width="387" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr>
          <td width="28" class="tabla-top">&nbsp;</td>
            <td class="tabla-top">
			                         <?
                          // Mostrar error de Autentificación.
                          include ("aut_mensaje_error.inc.php");
                          if (isset($error_login)){
                          echo "<font face='Verdana, Arial, Helvetica, sans-serif' size='1' color='#FF0000'><b>Error: $error_login_ms[$error_login]</b></font><br><br>";
                          }
        ?>
			</td>
        </tr></table>
      </td></tr></table>
      </form>
       <?php include("../pie.php"); ?>
</body></html>
