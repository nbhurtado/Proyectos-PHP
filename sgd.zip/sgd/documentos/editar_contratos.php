<!DOCTYPE html>
<html>
<head>
	<title>Editar Contratos Gerenciales</title>
	<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
	<link rel="stylesheet" href="../documentos/css/editar.css">
	<link rel="stylesheet" href="../css/styles2.css">
</head>
<body>
	<?php 

		include('../documentos/encabezado.php');
		require('conexion.php');

		if(isset($_POST['editar']) && !empty($_POST['nro_registro']) && !empty($_POST['fecha_registro']) && !empty($_POST['dni_ruc']) && !empty($_POST['usuario_entidad']) && !empty($_POST['nro_contrato']) && !empty($_POST['dependencia'])
			&& !empty($_POST['cargo']) && !empty($_POST['folio']) && !empty($_POST['descripcion']) && !empty($_POST['fecha_inicio']) && !empty($_POST['fecha_fin']))
		{
			$nro_registro = $_POST['nro_registro'];
			$fecha_registro = $_POST['fecha_registro'];
			$dni_ruc = $_POST['dni_ruc'];
			$usuario_entidad = $_POST['usuario_entidad'];
			$nro_contrato = $_POST['nro_contrato'];
			$dependencia = $_POST['dependencia'];
			$cargo = $_POST['cargo'];
			$folio = $_POST['folio'];
			$descripcion = $_POST['descripcion'];
			$fecha_inicio = $_POST['fecha_inicio'];
			$fecha_fin = $_POST['fecha_fin'];
			$id = $_GET['id'];
			$sql = "UPDATE contratos SET nro_registro = '$nro_registro', fecha_registro = '$fecha_registro',dni_ruc='$dni_ruc', usuario_entidad = '$usuario_entidad', nro_contrato = '$nro_contrato', dependencia = '$dependencia',
										cargo = '$cargo', folio = '$folio', descripcion = '$descripcion', fecha_inicio = '$fecha_inicio', fecha_fin = '$fecha_fin' where id = " . $id;

			if (!mysql_query($sql,$miconex)) 
			{?>
				
				<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span><?php  die("No se pudo editar el contrato [".mysql_error($miconex)."]");?></div><?php
			}
			?><div class="alert alert-info" role="alert"><?php echo "Contrato editado con exito. ".mysql_affected_rows($miconex)." fila(s) insertada(s)";?> </div><?php	
		}

	?> 
		<h2>Editar Contratos Gerenciales</h2>
		
		<form action="<?php echo $_SERVER['PHP_SELF'] . '?id=' . $_GET['id']?>" method="POST">
			<?php 

				$sql = "SELECT * FROM contratos where id = " . $_GET['id'];

				$resultado = mysql_query($sql,$miconex);

				while ($fila = mysql_fetch_assoc($resultado)) 
				{			

					echo "<p><div class='form-group'>
			        <label class='control-label col-xs-9 col-md-2'>Registro N° : </label>
			        <div class='col-xs-9 col-md-2'>
			            <input type='text' name='nro_registro' class='form-control' value='$fila[nro_registro]' maxlength='10' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;''>
			        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Fecha Registro : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='fecha_registro' class='form-control' value='$fila[fecha_registro]'>
				        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-1'>DNI/RUC : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='dni_ruc' class='form-control' value='$fila[dni_ruc]'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Usuario o Entidad N° : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='usuario_entidad' class='form-control' maxlength='100' value='$fila[usuario_entidad]'>
				        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Contrato Gerencial N°: </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='nro_contrato' class='form-control' maxlength='100' value='$fila[nro_contrato]'>
				        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-1'>Dependencia: </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='dependencia' class='form-control' maxlength='100' value='$fila[dependencia]'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Cargo : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='cargo' class='form-control' maxlength='100' value='$fila[cargo]'>
				        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Folio : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='folio' class='form-control' maxlength='4' onKeypress='if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;' value='$fila[folio]'>
				        </div>
				    </div></p><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Descripción : </label>
				        <div class='col-xs-9 col-md-9'>
				            <input type='text' class='form-control' name='descripcion' rows='3' cols='100' value='$fila[descripcion]'>
				        </div>
				    </div></p><br><br><br>
				    <p><div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Fecha Inicio de Contrato:</label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text' name='fecha_inicio' class='form-control' value='$fila[fecha_inicio]'>
				        </div>
				    </div>
				    <div class='form-group'>
				        <label class='control-label col-xs-9 col-md-2'>Fecha Final de Contrato : </label>
				        <div class='col-xs-9 col-md-2'>
				            <input type='text'name='fecha_fin' class='form-control' value='$fila[fecha_fin]'>
				        </div>
				    </div></p><br><br><br>";	
				}
			?>
			<center><input type="submit" value="Guardar Cambios" class="btn btn-danger" name="editar">
		</form>
		<a href="../documentos/menu.php"><img class="img-rounded" src="../imagenes/regresar.png" width="50" height="50"></a>
</body>
</html>