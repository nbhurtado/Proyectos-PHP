<?php 
function Conectarse(){

$host = "localhost";
$base = "documentos";
$link=mysql_connect($host,"root","123456") or die("Error de conexion al servidor");
$db=mysql_select_db($base, $link) or die("Error de conexion a la BD");
return $link;
}
 ?>
<?php
	//crear el objeto de conexion
	$miconex = mysql_connect("localhost","root","123456","documentos"); 
	mysql_select_db("documentos",$miconex); 
	//comprobar conexion
	if ($miconex->connect_errno) 
	{
		die("Fallo la conexion [".$miconex->connect_error."]");
	}
	echo "";
/////
function generarcodigo($tabla,$campocodigo,$link){
//Global $link;
$rsTabla=mysql_query("select $campocodigo from $tabla",$link) or die("$rsTabla" . mysql_error());
$ATabla=mysql_fetch_array($rsTabla);
//para extraer de la derecha se multiplica por -1
$numcaracteres=mysql_field_len($rsTabla,0)*(-1);
$nreg=$ATabla[0];
if($nreg>0){
	$rsTabla=mysql_query("select $campocodigo from $tabla order by $campocodigo desc", $link) or die ("Error 2" . mysql_error());
	$ATabla=mysql_fetch_row($rsTabla);
}
$cod=$ATabla[0]+1;
$cod="00000000000000".$cod;
$generado=substr($cod,$numcaracteres);
mysql_free_result($rsTabla);
return $generado;
}
////
function selectionsimple($campos,$tabla,$condicion){
Global $link;
if($condicion==''){
$sql="select ".$campos." from ".$tabla;
}else{
$sql="select ".$campos." from ".$tabla." where ".$condicion;
}
//echo $sql;
$rs=mysql_query($sql,$link) or die("Error " . mysql_error());
return $rs;
}
//FUNCION DE FECHA ACTUAL
function fecactual(){
$fecha=date("Y-m-d");
return $fecha;
}
//TERMINO DE FUNCION DE FECHA


function paginar($limite, $sql, $tabla, $titulo,$mantenimiento,$php_self){
// *** TODO SQL TIENE QUE LLEVAR 'AS' PARA RENOMBRAR A LOS CAMPOS ****
Global $valor; //valor del formulario buscar
Global $columna; //opcion de busqueda del formulario buscar
Global $ordenarpor; //campo por ordenar
Global $ordenactual; //campo actual ordenado
Global $sentido; //Ascendente o Descendente
Global $pagina; //Es el numero de pagina que se mostrara
Global $link; //Es el link de la conexion a la Base de Datos
// $php_self; //Pagina que llama al script se le debe pasar $PHP_SELF

$php_self = basename($php_self);
/***
$limite = 	Numero de registros a mostrar por pagina
$sql 	= 	Sql para concatenar con el LIMIT
$tabla 	=	Nombre de la tabla que se le pasa a la funcion "MostrarTabla"
$titulo =	Muestra un Titulo en el Listado
$mantenimiento= Si mantenimiento es 1 se muestran las opciones para eliminar, editar y agregar registros
*/


$nregmax = $limite;
$rs=mysql_query($sql,$link) or die("<b>Error en la Consulta SQL:</b><br>$sql<br>" . mysql_error());

// Hallamos el verdadero Nombre del Campo y no definido por AS del SELECT
$a = split( ' as ',  strtolower($sql));
$ncampos = mysql_num_fields($rs);
$n=0;
foreach ($a as $v){
	if($n<$ncampos){
		$camporeal[] =  trim(strstr("$v", " ")) ;
	}
	$n++;
}

?>
<script language="JavaScript" >
function imprimir()
{
window.print();
}
</script>

<?
//*************************


//*************************
$totalfilas = mysql_num_rows($rs);
//Registros que se mostraran
if(empty($pagina))$pagina = 1; //pagina por defecto
$limitevalor =  $pagina*$nregmax-($nregmax);
//criterio de ordenamiento
if(empty($ordenarpor))$ordenarpor = "1"; //por defecto el primer campo
//Sentido de ordenamiento Ascendente o Descendente
if($ordenactual==$ordenarpor){
	if($sentido=="Desc"){
		$sentido="Asc";
	}else{
		$sentido="Desc";
	}
}else{
	$sentido="Asc";
}
$ordenactual=$ordenarpor;
//empezando de $limite mostrar $limitevalor registros
//Limit $limite , $limitevalor
$rs_lim=mysql_query("$sql Order By $ordenarpor $sentido LIMIT $limitevalor, $limite",$link) or die ("Error en el ordenamiento...");
MostrarTabla($rs_lim,$tabla,$titulo,$pagina,$ordenactual,$sentido,$mantenimiento, $php_self);
if(mysql_num_rows($rs_lim)>0){
?>
<link href="../css/styles2.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
<link rel="stylesheet" href="../documentos/js/bootstrap.min.js">
<?
$numdepaginas = ceil($totalfilas/$nregmax);
//Script de Empaginado
//*************************************
$final = $numdepaginas;
$inicio = 1;
$limite =10; if($limite<3) echo "Error limite no pude ser menor que 3";
$lado = floor($limite/2);
if(empty($pagina)) $pagina=1;

$desde = $pagina-$lado;
$hasta = $pagina+$lado;

if($desde<$inicio) {$desde=$inicio; $hasta=$limite; }
if($hasta>$final)  {$desde=$final-$limite+1; $hasta=$final;}
if($numdepaginas<=$limite){$desde=$inicio;$hasta=$final;}

$x=0;


//**********************************
//Si movio a la 2 pagina mostrar << Inicio
if($pagina>1){
	//Inicio
    ?>
    &nbsp;<font size=1><A HREF="<?=$PHP_SELF?>?pagina=1&ordenarpor=<?=$ordenarpor?>&ordenacual=<?=$ordenactual?>&sentido=<?=$sentido?>"><< Inicio</A>&nbsp;|</font>&nbsp;
    <?
	//Atras
	?>
    &nbsp;<font size=1><A HREF="<?=$PHP_SELF?>?pagina=<?=$pagina-1?>&ordenarpor=<?=$ordenarpor?>&ordenacual=<?=$ordenactual?>&sentido=<?=$sentido?>">< Atras</A>&nbsp;|</font>&nbsp;
	<?
}
for($i=$desde;$i<=$hasta;$i++){
//for($i=1; $i <= $numdepaginas; $i++) {
	if($i!=$pagina){
	?> &nbsp;<font size=1><A HREF="<?=$PHP_SELF?>?pagina=<?=$i?>&ordenarpor=<?=$ordenarpor?>&ordenacual=<?=$ordenactual?>&sentido=<?=$sentido?>"><?=$i?></A></font>&nbsp; <?
	}else{
	?> &nbsp;<font size=2 color="red"><b><?=$i?></b></font>&nbsp; <?
	}
	$x++; if($x>=$limite)break;
}
//if($numdepaginas>1){
if($pagina<$numdepaginas){
	//Siguiente
	?>
	    &nbsp;<font size=1>|&nbsp;<A HREF="<?=$PHP_SELF?>?pagina=<?=$pagina+1?>&ordenarpor=<?=$ordenarpor?>&ordenacual=<?=$ordenactual?>&sentido=<?=$sentido?>">Siguiente ></A>&nbsp;</font>&nbsp;
	    &nbsp;<font size=1>|&nbsp;<A HREF="<?=$PHP_SELF?>?pagina=<?=$numdepaginas?>&ordenarpor=<?=$ordenarpor?>&ordenacual=<?=$ordenactual?>&sentido=<?=$sentido?>">Final >></A></font>
	<?
}

?>
<?
}
mysql_free_result($rs);
}


function MostrarTabla($rs,$tabla, $titulo,$pagina,$ordenactual,$sentido,$mantenimiento, $php_self){
$campos= mysql_num_fields($rs);
$numfilas= mysql_num_rows($rs);
?>
<script language="JavaScript" type="text/JavaScript" src="../jquery/funciones.js"></script>
<link rel="stylesheet" href="../documentos/css/bootstrap.min.css">
<link rel="stylesheet" href="../documentos/js/bootstrap.min.js">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<form name="form1" method="post" action="eliminar_<?=$tabla?>.php">
<div class="table-responsive" id="tabla">
  <table  class="table table-bordered table-hover table striped" id="tbLista" >
    <td colspan="<?=$campos+1?>" class="tabla-top"><center><?=$titulo?></center></td>
    <tr>
	  <?
	  if ($mantenimiento==1){
	  ?>
	  <? if($numfilas>0){ ?>
	 <td class="tabla-top2"><center>Mantenimiento</center></td>
	  <? }
	  }
	  for($i=1;$i<$campos;$i++)
	  {
	  ?>
      <td class="tabla-top2">
        <?
		$campo=$i+1;
		echo "<a href=".$PHP_SELF."?pagina=".$pagina."&ordenarpor=".$campo."&ordenactual=".$ordenactual."&sentido=".$sentido.">". mysql_field_name($rs,$i)."</a>";
		?>      </td>
      <?
	  }
	  ?>
      </tr>
	  <?
	  if(mysql_num_rows($rs)==0) echo "<tr><td colspan=$campos align='center'><font color='#336699' size='3' face='verdana,arial'><b>No hay registros</b></font></td></tr>";
	  $n=0;
	  while($filas=mysql_fetch_row($rs)){
	  if($n%2==0){?>
      <tr onMouseover="fila(this)" name="<?=$filas[0]?>" bgcolor="#EEEEEE">
	  <? } else { ?>
       <tr onMouseover="fila(this)" name="<?=$filas[0]?>" bgcolor="#FFFFFF">
	  <? }
	  $n++;
	  if ($mantenimiento==1){
	  ?>
	  <? if($numfilas>0){ ?>
     </td>

      <td class="campo1"><a href="editar_<?=$tabla?>.php?id=<?=$filas[0]?>"><img src="../imagenes/editar.png" width="16" height="16" border="0"></a>
       	<button type="button" data-toggle="modal" data-target="#miModal"><img src="../imagenes/eliminar.png" width="16" height="16" border="0"></button>
					    <div class="modal fade" id="miModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					      <div class="modal-dialog">
					        <div class="modal-content">
					          <div class="modal-header">
					            <button type="button" class="close" data-dismiss="modal">
					            </button>					            
					          </div>
					          <div class="modal-body">
						        <p class="borrar">¿Estas seguro que quieres eliminar este documento?</p>
						      </div>
					          <div class="modal-footer">
					            <a href="eliminar_<?=$tabla?>.php?id=<?=$filas[0]?>"><button type="button" class="btn btn-info">Si</button></a>
					            <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
					          </div>
					        </div>
					      </div>				      
						</div>
	  </td>
	  <? }
	  }
	  for($i=1;$i<$campos;$i++){ ?>
      <td class="campo">
        <?=$filas[$i]?>      </td>
      <?
		}
	  ?>
    </tr>
    <?
  }	
  ?>

  <?
  if ($mantenimiento==1)
  {
  ?>
  <tr>
	  <? if($numfilas>0){ ?> <td></td>
	  <td></td>
	  <? } ?>
	  <td></td>
    </tr>
  <?
  }

  ?>
  </table></div>

</form>

<? }
 ?>
<?php  ?>
