<footer>
		<marquee>
		<table align="center">
        <tr>
        <td>&nbsp; </td><td>&nbsp; </td><td>&nbsp; </td><td>&nbsp; </td><td>&nbsp; </td><td>&nbsp; </td><td>&nbsp; </td><td>&nbsp; </td>
        <td><img src="../imagenes/icono.png" width="42" height="36"></td>
        <link rel="stylesheet" href="../css/estilos.css">
        <td>&nbsp;Sistema Gestión de Documentos - All Rights Reserved &copy;Nilton</td></tr></table>
        </marquee>
</footer>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>