<body>	
<style type="text/css">
	body{
		height:80%;
		padding:20px 0;
		background-color: #6cc;
		background-position: center;
	}
	section{
		position: center;
		background-color: white;
	}
</style>
</body>