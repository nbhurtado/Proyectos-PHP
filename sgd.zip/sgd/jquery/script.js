function reportePDF(){
	var desde = $('#bd-desde').val();
	var hasta = $('#bd-hasta').val();
	window.open('../documentos/reporte.php?desde='+desde+'&hasta='+hasta);
}
