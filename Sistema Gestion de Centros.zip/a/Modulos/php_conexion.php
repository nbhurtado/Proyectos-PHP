<?php

	$conexion = mysql_connect("localhost","ddeunamb_admin","admin2016");
	mysql_select_db("ddeunamb_centros_u",$conexion);
    mysql_query("SET NAMES utf8");
	mysql_query("SET CHARACTER_SET utf");
	$s='$';




	function limpiar($tags){


		return $tags;
	}


?>
