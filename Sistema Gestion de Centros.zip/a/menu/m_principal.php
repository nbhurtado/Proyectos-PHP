<div class="navbar navbar-default navbar-fixed-top">
     <div class="container">
       <div class="navbar-header">
         <a href="../" class="navbar-brand">Sistema Gesti&oacute;n de Centros UNAMBA</a>
         <button class="navbar-toggle btn btn-navbar" type="button" data-toggle="collapse" data-target="#navbar-main">
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
         </button>
       </div>
       <div class="navbar-collapse collapse" id="navbar-main">
         <ul class="nav navbar-nav" id="letra">
           <li ><a href="Modulos/Profesor">Administrar Profesores</a></li>
           <li ><a href="Modulos/Alumnos">Administrar Alumnos</a></li>
           <li ><a href="Modulos/Datos">Administrar Informacion</a></li>
         </ul>
         <ul class="nav navbar-nav navbar-right" id="letra">
             <li class="divider-vertical"></li>
             <li class="dropdown">
               <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                 <span style="color:#FFF">Hola, <?php echo $_SESSION['user_name']; ?></span> <b class="caret" id="tr"></b>
               </a>
               <ul class="dropdown-menu" >
                 <li><a href="cambiar_info.php" id="letra"><i class="icon-user"></i> Actualizar Informaci&oacute;n</a></li>
                 <li><a href="cambiar_contra.php" id="letra"><i class="icon-refresh"></i> Cambiar Contraseña</a></li>
                 <li class="divider"></li>
                 <li><a href="php_cerrar.php" id="letra"><i class="icon-off"></i> Salir</a></li>
               </ul>
           </li>
         </ul>
       </div>
     </div>
   </div>
